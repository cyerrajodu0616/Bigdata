//
//  ViewController.m
//  restapiforuserlocation
//
//  Created by Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student) on 6/17/15.
//  Copyright (c) 2015 Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student). All rights reserved.
//

#import "ViewController.h"


#define BASE_URL "http://nlpservices.mybluemix.net/api/service"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
