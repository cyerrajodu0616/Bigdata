//
//  ViewController.h
//  restapiforuserlocation
//
//  Created by Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student) on 6/17/15.
//  Copyright (c) 2015 Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

