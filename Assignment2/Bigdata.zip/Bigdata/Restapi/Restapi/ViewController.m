//
//  ViewController.m
//  Restapi
//
//  Created by Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student) on 6/17/15.
//  Copyright (c) 2015 Yerrajodu, Chiranjeevi Raghavendra  . (UMKC-Student). All rights reserved.
//

#import "ViewController.h"

#import "AFHTTPRequestOperationManager.h"

#define BASE_URL "http://www.datasciencetoolkit.org/street2coordinates/"

#define google_api_key "AIzaSyC2BMYB2x2yx6ZBNIAbuhXvefUfjsZFGAI"

@interface ViewController (){
    
}

@property (nonatomic, weak) NSString *latitude;
@property (nonatomic, weak) NSString *longitude;
@property (weak, nonatomic) IBOutlet UILabel *latitude1;
@property (weak, nonatomic) IBOutlet UILabel *longitude1;


@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)tappedOnTokenize:(id)sender {
    
    [_sentenceTextField resignFirstResponder];  //To hide the keyboard
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *sentense = [_sentenceTextField.text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    NSString *url = [NSString stringWithFormat:@"%s%@", BASE_URL, sentense];
    
    NSLog(@"%@", url);
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"JSON: %@", responseObject);
        

        NSDictionary *dict = (NSDictionary *)responseObject;
        NSString *key = [dict allKeys][0];
        NSLog(@"Latitude JSON VALUE:%@",responseObject[key][@"latitude"]);
        NSLog(@"Longitude JSON VALUE:%@",responseObject[key][@"longitude"]);
       //sNSLog(@"JSON1: %@", [ responseObject objectForKey:@"latitude"]);
        
        _latitude = responseObject[key][@"latitude"];
        _longitude = responseObject[key][@"longitude"];
        
        _latitude1.text = [NSString stringWithFormat:@"%@", self.latitude];
       _longitude1.text = [NSString stringWithFormat:@"%@", self.longitude];

        
        //[_responseTableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:[error description]
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
        [alert show];
    }];
    
}

@end
